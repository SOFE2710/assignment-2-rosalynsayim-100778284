import java.util.Vector;


public class Student {
	private String id;
	private String name;
	private Vector<Course> courses; // contains all courses the student is registered in

	public Student(String stdName, String stdId) {
		this.name = stdName;
		this.id = stdId;
		courses = new Vector<>();
	}

	public void registerFor(Course course) {
		// using if contidion to check if course is present in courses
		if(!this.courses.contains(course)) {
			// adding course if not present
			this.courses.add(course);
		}
	}


	public boolean isRegisteredInCourse(Course course) {
		//Returns if student is registered in course
		return (courses.contains(course));
	}

	public String getName() {
		return this.name;
	}

	public String getId() {
		return this.id;
	}

	public String toString() {
		// return a string representation of a student using the following format:
		// 100234546 John mcDonald
		// Registered courses: ELEE 2110, ELEE 2790, SOFE 2710, SOFE 2800, SOFE 2850
		String student = id + " " + name + "\r\n" + "Registered courses: " + courses;
		return student;
	}
}

