import java.util.Vector;


public class Course {
    private Department dept;
    private String title; // title of the course (eg. Intro to programming);
    private String code; // course code, eg. SOFE, ELEE, MANE, etc.
    private int number; // course number, eg. 1200, 2710, 2800, etc.
    Vector<Student>classList; // contains all students registered in the course


    public Course(String code, int number, Department dept, String title) {
        // also initialize the classList;
        this.code = code;
        this.number = number;
        this.dept = dept;
        this.title = title;
        classList = new Vector<>();
    }

    public Course() {
        // TODO Auto-generated constructor stub
    }

    public Department getDept () {
        return this.dept;
    }

    public String getCode() {
        return this.code;
    }

    public int getNumber() {
        return this.number;
    }

    public int getCourseNumber() {
        return number;
    }

    public void addStudentToCourse(Student student){
        classList.add(student);

    }
    public Vector<Student> getClassList() {
        return classList;
    }

    public String toString() {
        // return a string representation of the course with the course code,
        // name, and number of people registered in the course in th following format:
        // SOFE 2710 Object Oriented Programming and Design, Enrollment = 260
        return this.code + " " + this.number + " " + this.title + ", Enrollment = " + this.classList.size();
    }

}