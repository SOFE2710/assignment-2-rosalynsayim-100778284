import java.util.Vector;


public class Department {
   private String name; // the name of school Dept of Computing and Info Science
   private String id; // short name for courses SOFE, ELEE, STAT, etc
   private Vector<Course> courseList; // all courses offered by the department
   private Vector<Student> registerList; // all students taking courses in the department

   public Department(String name, String id) {
      // Initializing all the vectors
      this.name = name;
      this.id = id;
      courseList = new Vector<>();
      registerList = new Vector<>();
   }

   public void offerCourse(Course course) {
      this.courseList.add(course);
   }

   public void printCoursesOffered() {
      System.out.println("List of courses offered by the department: ");
      for(Course course: this.courseList) {
         System.out.println(course);
      }
   }

   public void printStudentsByName() {
      System.out.println("List of all the students taking courses in this department: ");
      // using enhanced for loop to iterate over registerList
      for(Student student: registerList) {
         System.out.println(student);
      }
   }

   public void registerStudentCourseInDepartment(Student studentToBeResgiteredinDep, Course CourseToBeRegisteredIn) {
      if (isStudentRegistered(studentToBeResgiteredinDep)) {
         registerList.add(studentToBeResgiteredinDep);
         studentToBeResgiteredinDep.registerFor(CourseToBeRegisteredIn);
      }
   }

   public Vector<Student> studentsRegisteredInCourse(int number) {
      for (Course course : courseList) {
         if (course.getNumber() == number)
            return course.classList;
      }
      return null;
   }
   public boolean isStudentRegistered(Student student) {
      return registerList.contains(student);
   }

   public void printStudentsRegisteredInCourse(int number) {
      // if there are no students registered in the given course, printing None
      if (studentsRegisteredInCourse(number).isEmpty()) {
         System.out.println("None");
         return;
      }
      for (Student student : studentsRegisteredInCourse(number)) {
         System.out.println(student.getId() + ", " + student.getName());
      }
   }

   public String getName() {
      return this.name;
   }

   public String getId() {
      return this.id;
   }

   public String largestCourse() {
      Vector<Student> StudentCount = new Vector<>();
      int count = 0;
      String course = null;
      for (int i = 0; i < courseList.size(); i++) {
         StudentCount = courseList.elementAt(i).getClassList();
         if (StudentCount.size() > count) {
            count = StudentCount.size();
            course = courseList.elementAt(i).toString();
         }
      }
      return course;
   }
   public String toString() {
      // returns a string representation of department name, number of courses offered
      // and number of students registered in the department. Use the format:
      // ECSE: 53 courses, 460 students

      return this.name + ": " + this.courseList.size() + "courses, " + this.registerList.size() + "students";
   }
}